README.txt 

The hAPI.jar was compiled using the jdk v1.8.0 64 bit

To use the hAPI in your own processing sketch you can add the file within the processing window by selecting Sketch/Add File/<path to hAPI.jar>. 
 
