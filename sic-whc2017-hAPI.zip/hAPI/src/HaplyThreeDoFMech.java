import static java.lang.Math.*;

public class HaplyThreeDoFMech extends Mechanisms{
	
	public HaplyThreeDoFMech(){
	}
	
	public void forwardKinematics(float[] angles){
	}
	
	public void torqueCalculation(float[] force){
	}
	
	public void forceCalculation(){
	}
	
	public void positionControl(){
	}
	
	public void inverseKinematics(){
	}
	
	
	public void set_mechanism_parameters(float[] parameters){
	}
	
	public float[] get_coordinate(){
		float temp[] = {0, 0};
      	return temp;
	}
	
	public float[] get_torque(){
		float temp[] = {0, 0};
      	return temp;
	}
	
	public float[] get_angle(){
		float temp[] = {0, 0};
      	return temp;
	}


}