public enum DeviceType {
    HaplyOneDOF, HaplyTwoDOF, HaplyThreeDOF, HaplyFourDOF, HapticPaddle
}